#include <stdio.h>
#include "trafo.h"
#include "types.h"

//#define N 8
//#define M 4


#define FACTOR ( (unsigned char) ( 255/(N+M-2) ) )

// Defincion de funciones y variables declaradas en ensamblador

extern void contarUnos(int matriz[N][M], int, int, int);
// Subrutina opcional de la práctica para subir nota
extern int resizeMatrix(int matriz[N][M]);

//---------------------------------------------------------------


pixelRGB imagenRGB[N][M];
int imagenGris[N][M];
int imagenBinaria[N][M];
int unosPorFila[N];
int imagenComprimida;

void initRGB(pixelRGB m[N][M], int nfilas, int ncols) {

    int i,j;
    
    for (i=0;i<nfilas;i++)
        for (j=0; j<ncols; j++) {
            m[i][j].R = (i+j)*FACTOR;
            m[i][j].G = (i+j)*FACTOR;
            m[i][j].B = (i+j)*FACTOR;
            //(i+j)*FACTOR
        }
}



int main() {
    
    // 1. Crear una matriz NxM de diferentes colores

	initRGB(imagenRGB,N,M);

	// 2. Traducir la matriz RGB a una matriz de grises

    RGB2GrayMatrix(imagenRGB,imagenGris,N,M);

    // 3. Traducir la matriz de grises a una matriz en blanco y negro

    Gray2BinaryMatrix(imagenGris,imagenBinaria,N,M);

    // Contar los unos que aparecen por filas en la matriz de blanco y negro

    contarUnos(imagenBinaria,unosPorFila,N,M);

    // Comprimimos la matriz para que solamente ocupe una palabra de 32 bits

    imagenComprimida = resizeMatrix(imagenBinaria);

    while(1);
    return 0;
}
